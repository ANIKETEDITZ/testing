# Interactive particles text create with three.js 

A Pen created on CodePen.io. Original URL: [https://codepen.io/sanprieto/pen/XWNjBdb](https://codepen.io/sanprieto/pen/XWNjBdb).

